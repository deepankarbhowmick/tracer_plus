import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import com.sap.it.api.pd.PartnerDirectoryService
import com.sap.it.api.ITApiFactory
import com.sap.it.api.pd.BinaryData
import groovy.json.JsonSlurper
import scan.deep.xml.Scanner

def Message deepScan(Message message) {
    HashMap<String, ArrayList<String>> mplLog
    BinaryData binary
    PartnerDirectoryService pd = ITApiFactory.getApi(PartnerDirectoryService.class, null)
    def messageLog = messageLogFactory.getMessageLog(message)
    String body = message.getBody(String.class)
    try{
        binary = pd.getParameter(message.getProperties().get('id'), 
                                 message.getProperties().get('partnerId'), 
                                 com.sap.it.api.pd.BinaryData.class)
        if(body == null || body == '' || BinaryData == null){
            return message
        }
        else{
            mplLog = new Scanner().scan(binary.getData(),
                                        body,
                                        message.getHeaders().get('interfaceId'))
            if(messageLog != null){
                mplLog.each {
                    String key, ArrayList<String> value ->
                        messageLog.addCustomHeaderProperty(key, value.toString())
                }
            }
            return message
        }
    }
    catch(Exception exception){
        messageLog.addCustomHeaderProperty('exception', exception.getMessage())
        return message
    }
}